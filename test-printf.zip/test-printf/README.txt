sh test-printf/test-printf.sh
